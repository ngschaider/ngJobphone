Locales['en'] = {
	["new_number"] = "New number: %s",
	["not_occupied"] = "This phone is not occupied.",
	["already_occupied"] = "This phone is already occupied.",
	
	["menu_title"] = "Job Phone",
	["menu_subtitle"] = "",
	
	["occupied_by"] = "Occupied by: %s",
	["not_occupied"] = "Not occupied",
	["take_phone"] = "Take phone",
	["return_phone"] = "Return phone",
	
	["return_phone_success"] = "Successfully returned phone.",
	["return_phone_error"] = "Error while returning phone.",
	
	["take_phone_success"] = "Successfully took phone.",
	["take_phone_error"] = "Error while taking phone.",
};